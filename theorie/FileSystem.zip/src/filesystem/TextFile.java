package filesystem;

/**
 * @author wijnand.schepens@hogent.be
 */
public class TextFile extends AFile
{
	private String content;
	
	public TextFile(String name, String content)
	{
		super(name);
		this.content = content;
	}

	@Override
	public int getSize()
	{
		return content.length();
	}

	@Override
	public void printTree(int indent)
	{
		// do nothing
	}
	
}
