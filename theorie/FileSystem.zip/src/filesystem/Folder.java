package filesystem;


import java.util.ArrayList;
import java.util.List;

/**
 * @author wijnand.schepens@hogent.be
 */
public class Folder extends AFile
{
	//private ArrayList<Folder>   subfolders;
	//private ArrayList<TextFile> textFiles;
	
	private List<File> files = new ArrayList<>();
	
	public Folder(String name)
	{
		super(name);
	}
	
	public void add(File file)
	{
		files.add(file);
	}

	@Override
	public int getSize()
	{
		int size = 0;
		for (File file: files)
			size += file.getSize();
		return size;
	}

	public void printDir()
	{
		for (File file: files)
			System.out.println(file.getName());
	}
	
	@Override
	public void printTree(int indent)
	{
		for (File file: files)
		{
			printIndent(indent);
			System.out.println(file.getName());
//			if (file instanceof Folder)
//				((Folder)file).printTree(indent + 1);
			file.printTree(indent + 1);
		}
	}
	
	private void printIndent(int indent)
	{
		for (int i = 0; i < indent; i++)
			System.out.print("  ");
	}
}
