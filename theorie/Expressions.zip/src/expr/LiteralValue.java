package expr;

/**
 * @author wijnand.schepens@hogent.be
 */
public class LiteralValue implements Expression
{
	private double value;

	public LiteralValue(double value)
	{
		this.value = value;
	}

	@Override
	public double evaluate()
	{
		return value;
	}
	
	
}
