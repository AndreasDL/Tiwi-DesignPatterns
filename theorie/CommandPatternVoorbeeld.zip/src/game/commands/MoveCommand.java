package game.commands;

import game.Command;

/**
 * @author wijnand.schepens@hogent.be
 */
public abstract class MoveCommand implements Command
{
	protected int numberOfSteps;

	public MoveCommand(int n)
	{
		this.numberOfSteps = n;
	}
}
