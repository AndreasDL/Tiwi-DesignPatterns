package filesystem;

/**
 * @author wijnand.schepens@hogent.be
 */
public abstract class AFile implements File
{
	private String name;

	public AFile(String name)
	{
		this.name = name;
	}

	@Override
	public String getName()
	{
		return name;
	}
	
	
}
