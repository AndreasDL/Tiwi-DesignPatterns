package game.commands;

/**
 * @author wijnand.schepens@hogent.be
 */
public class GoUpCommand extends MoveCommand
{

	public GoUpCommand(int n)
	{
		super(n);
	}

	@Override
	public void execute()
	{
		System.out.println("Going " + numberOfSteps + " steps right.");
	}

}
