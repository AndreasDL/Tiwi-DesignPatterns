package game.commands;

import game.Command;

/**
 * @author wijnand.schepens@hogent.be
 */
public class ShootCommand implements Command
{
	@Override
	public void execute()
	{
		System.out.println("Shoot");
	}

}
