package board;


/**
 * @author wijnand.schepens@hogent.be
 */
public class Board 
{
	public void goLeft(int n) 
	{
		System.out.println("Going " + n + " steps left");
	}
	
	public void goRight(int n )
	{
		System.out.println("Going " + n + " steps right");
	}
	
	public void goUp(int n) 
	{
		System.out.println("Going " + n + " steps up");
	}
	
	public void goDown(int n )
	{
		System.out.println("Going " + n + " steps down");
	}
	

	public void shoot()
	{
		System.out.println("Shoot");
	}
	

}
