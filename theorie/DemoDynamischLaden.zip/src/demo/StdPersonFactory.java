package demo;

/**
 * @author wijnand.schepens@hogent.be
 */
public class StdPersonFactory implements PersonFactory
{

	@Override
	public Person createPerson()
	{
		return new Person("Jan");
	}

}
