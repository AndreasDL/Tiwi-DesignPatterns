package ui;


import game.Game;
import game.commands.GoDownCommand;
import game.commands.GoLeftCommand;
import game.commands.GoRightCommand;
import game.commands.GoUpCommand;
import game.commands.ShootCommand;
import java.util.Scanner;

/**
 * @author wijnand.schepens@hogent.be
 */
public class GameDemo 
{
	public static void main(String[] args)
	{
		Game game = new Game();
		
		Scanner in = new Scanner(System.in);
		
		System.out.print("Command? ");
		String cmd = in.next();
		while (!cmd.equals("einde"))
		{
			if ("shoot".equals(cmd))
			{
				//game.doAction(Action.SHOOT);
				game.doCommand(new ShootCommand());
			}
			else if ("left".equals(cmd))
			{
//				game.doAction(Action.LEFT);
				int n = in.nextInt();
//				game.doAction(Action.LEFT, n);
				game.doCommand( new GoLeftCommand(n) );
			}
			else if ("right".equals(cmd))
			{
//				game.doAction(Action.RIGHT);
				int n = in.nextInt();
//				game.doAction(Action.RIGHT, n);
				game.doCommand( new GoRightCommand(n) );
			}
			else if ("up".equals(cmd))
			{
//				game.doAction(Action.UP);
				int n = in.nextInt();
//				game.doAction(Action.UP, n);
				game.doCommand( new GoUpCommand(n) );
			}
			else if ("down".equals(cmd))
			{
//				game.doAction(Action.DOWN);
				int n = in.nextInt();
//				game.doAction(Action.DOWN, n);
				game.doCommand( new GoDownCommand(n) );
			}
			else
				System.out.println("Onbekend commando");
			
			System.out.print("Command? ");
			cmd = in.next();
		}
		
		System.out.println("REPLAY:");
		game.replay();
	}
	
	
}
