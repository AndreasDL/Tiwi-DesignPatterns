package game;

/**
 * @author wijnand.schepens@hogent.be
 */
public enum Action 
{
	// SHOOT, LEFT, RIGHT, UP, DOWN;
}
