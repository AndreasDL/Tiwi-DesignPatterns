package game.commands;

/**
 * @author wijnand.schepens@hogent.be
 */
public class GoRightCommand extends MoveCommand
{
	public GoRightCommand(int n)
	{
		super(n);
	}

	@Override
	public void execute()
	{
		System.out.println("Going " + numberOfSteps + " steps right.");
	}
	
}
