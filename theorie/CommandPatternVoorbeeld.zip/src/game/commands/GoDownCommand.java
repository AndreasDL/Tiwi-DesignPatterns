package game.commands;

/**
 * @author wijnand.schepens@hogent.be
 */
public class GoDownCommand extends MoveCommand
{
	public GoDownCommand(int n)
	{
		super(n);
	}

	@Override
	public void execute()
	{
		System.out.println("Going " + numberOfSteps + " steps right.");
	}

}
