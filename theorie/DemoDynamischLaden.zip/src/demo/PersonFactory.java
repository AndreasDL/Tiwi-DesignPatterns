package demo;

/**
 * @author wijnand.schepens@hogent.be
 */
public interface PersonFactory 
{
	Person createPerson();
}
