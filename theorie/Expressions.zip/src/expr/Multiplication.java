package expr;

/**
 * @author wijnand.schepens@hogent.be
 */
public class Multiplication implements Expression
{
	private Expression operand1;
	private Expression operand2;

	public Multiplication(Expression operand1, Expression operand2)
	{
		this.operand1 = operand1;
		this.operand2 = operand2;
	}
	

	@Override
	public double evaluate()
	{
		return operand1.evaluate() * operand2.evaluate();
	}
}
