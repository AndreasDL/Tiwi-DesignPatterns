package expr;

/**
 * @author wijnand.schepens@hogent.be
 */
public interface Expression 
{
	double evaluate();
}
