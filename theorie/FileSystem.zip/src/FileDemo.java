
import filesystem.Folder;
import filesystem.TextFile;

/**
 * @author wijnand.schepens@hogent.be
 */
public class FileDemo 
{
	public static void main(String[] args)
	{
		Folder root = new Folder("root");
		
		TextFile tf1 = new TextFile("tf1", "blabla");
		root.add(tf1);
		
		TextFile tf2 = new TextFile("tf2", "blablabla");
		root.add(tf2);
		
		Folder folder1 = new Folder("folder1");
		root.add(folder1);
		
		folder1.add(new TextFile("tf3", "bla"));
		
		Folder folder2 = new Folder("folder2");
		folder1.add(folder2);
		
		folder2.add(new TextFile("tf4", ""));
		
		
		System.out.println(root.getSize());
		System.out.println(root.getName());
		
		System.out.println("Dir:");
		root.printDir();
		
		System.out.println("Tree:");
		root.printTree(0);
	}
}
