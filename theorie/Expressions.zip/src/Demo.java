
import expr.Addition;
import expr.Expression;
import expr.LiteralValue;
import expr.Multiplication;

/**
 * @author wijnand.schepens@hogent.be
 */
public class Demo 
{
	public static void main(String[] args)
	{
		Expression e = 
			new Multiplication(
				new LiteralValue(2),
				new Addition(
					new LiteralValue(3), 
					new LiteralValue(4)
				)
			);
		
		System.out.println(e.evaluate());
	}
}
