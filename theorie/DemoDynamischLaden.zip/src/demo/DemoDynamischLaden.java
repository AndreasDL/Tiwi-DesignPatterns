package demo;

import java.lang.reflect.Constructor;

/**
 * @author wijnand.schepens@hogent.be
 */
public class DemoDynamischLaden 
{
	
	public static void main(String[] args) throws Exception 
	{
		if (args.length < 1)
		{
			System.out.println("Geef een fully qualified klassenaam als commandline-parameter mee\n"
					+ "bv. test.StdPersonFactory");
		}
		else
		{
			//PersonFactory factory = new StdPersonFactory();
			
			String factoryName = args[0];
			Class c = Class.forName(factoryName);
			Constructor con = c.getConstructor();
			PersonFactory factory = (PersonFactory)con.newInstance();

			Person p = factory.createPerson();

			System.out.println(p.getName());
		}
    }
}
