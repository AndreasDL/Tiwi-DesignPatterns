package filesystem;

/**
 * @author wijnand.schepens@hogent.be
 */
public interface File 
{
	int getSize();
	
	String getName();
	
	void printTree(int indent);
}
