package game.commands;

import game.Command;

/**
 * @author wijnand.schepens@hogent.be
 */
public class GoLeftCommand extends MoveCommand
{
	public GoLeftCommand(int n)
	{
		super(n);
	}
	
	@Override
	public void execute()
	{
		System.out.println("Going " + numberOfSteps + " steps left.");
	}

}
