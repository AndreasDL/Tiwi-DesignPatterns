package game;


import board.Board;
import java.util.ArrayList;

/**
 * @author wijnand.schepens@hogent.be
 */
public class Game 
{	
	private Board board;
	
	//private ArrayList<Action> actionHistory = new ArrayList<>();
	private ArrayList<Command> cmdHistory = new ArrayList<>();
	
	public Game()
	{
		board = new Board();
	}
	
//	public void doAction(Action action)
//	{
//		doActionWithoutStore(action);
//		actionHistory.add(action);
//	}
//	
//	public void doAction(Action action, int n)
//	{
//		doActionWithoutStore(action, n);
//		actionHistory.add(action); // ??
//	}
//
//	public void doActionWithoutStore(Action action)  // probl met param
//	{
//		if (action == Action.SHOOT)
//			board.shoot();
//		else if (action == Action.LEFT)
//			board.goLeft(1);
//		else if (action == Action.RIGHT)
//			board.goRight(1);
//		else if (action == Action.UP)
//			board.goUp(1);
//		else if (action == Action.DOWN)
//			board.goDown(1);
//	}
//	
//	public void doActionWithoutStore(Action action, int n)  // probl met param
//	{
//		if (action == Action.LEFT)
//			board.goLeft(n);
//		else if (action == Action.RIGHT)
//			board.goRight(n);
//		else if (action == Action.UP)
//			board.goUp(n);
//		else if (action == Action.DOWN)
//			board.goDown(n);
//	}
	
	public void doCommand(Command cmd)
	{
		cmd.execute();
		
		cmdHistory.add( cmd );
	}
	
	
	
	public void replay()
	{
		System.out.println("replay:");
		
		this.board = new Board();
//		for (Action action: actionHistory)
//			doActionWithoutStore(action);
		
		for (Command cmd: cmdHistory)
			cmd.execute();
	}
}
