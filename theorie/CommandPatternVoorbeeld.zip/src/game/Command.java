package game;

/**
 * @author wijnand.schepens@hogent.be
 */
public interface Command 
{
	void execute();
}
